<?php
/**
 * Plugin Name: DTV Comment System
 * Plugin URI: https://ducdoblog.com
 * Description: Hệ thống Comment Điện Thoại Vui liên kết với CareSoft
 * Version: 1.0.0
 * Author: iRisVN
 * Author URI: https://ducdoblog.com
 * License: GPLv2 or later 
 */

define('DTV_COMMENTS_DIR', plugin_dir_path(__FILE__));

class DTV_Comments_System
{
    public function __construct(){
        include( DTV_COMMENTS_DIR . 'includes/comments-init.php');
        include( DTV_COMMENTS_DIR . 'api/api_init.php');
        include( DTV_COMMENTS_DIR . 'shortcode/showCommentForm.php');
        register_activation_hook( __FILE__, array($this,'create_database' ));
    }
    public function create_database(){
        global $wpdb;
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

        // check table exists
        $query_check = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

        if ( $wpdb->get_var( $query_check ) == $table_name ) 
        {
            return;
        } 
        else 
        {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                comment_ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                comment_post_ID bigint(20) unsigned NOT NULL DEFAULT '0',
                ticket_ID bigint(20) unsigned NOT NULL DEFAULT '0',
                comment_author tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
                comment_author_phone varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
                comment_author_email varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
                comment_author_IP varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
                comment_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                comment_content text COLLATE utf8mb4_unicode_520_ci NOT NULL,
                comment_status varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
                comment_parent bigint(20) unsigned NOT NULL DEFAULT '0',
                comment_type varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
                comment_is_admin tinyint(1) NOT NULL DEFAULT '0',
                PRIMARY KEY (comment_ID),
                KEY dtv_comment_post_ID (comment_post_ID),
                KEY dtv_ticket_ID (ticket_ID),
                KEY dtv_comment_date (comment_date),
                KEY dtv_comment_parent (comment_parent),
                KEY dtv_comment_author_phone (comment_author_phone),
                KEY dtv_comment_author_email (comment_author_phone),
                KEY dtv_comment_type (comment_type)
            )  $charset_collate ;";
            
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta( $sql );
        }
    }
}

new DTV_Comments_System();

?>