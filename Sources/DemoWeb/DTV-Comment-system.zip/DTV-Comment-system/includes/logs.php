<?php 
function writeCommentLog( $description )
{
    $commentFile = DTV_COMMENTS_DIR. "logs/comments_".date("Y-m-d").".txt";
    file_put_contents($commentFile, $description.PHP_EOL, FILE_APPEND);
}
function writeCommentErrorLog( $description )
{
    $commentFile = DTV_COMMENTS_DIR. "logs/comments_error_".date("Y-m-d").".txt";
    file_put_contents($commentFile, $description.PHP_EOL, FILE_APPEND);
}
?>