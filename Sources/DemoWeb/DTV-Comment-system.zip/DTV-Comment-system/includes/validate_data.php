<?php 

function validata_data_form( $data )
{
    if ( validate_int( $data->get_param('postID') ) && $data->get_param('author') && $data->get_param('phone') && validate_email( $data->get_param('mail') ) && $data->get_param('content') && validate_int( $data->get_param('parent') ) && validate_type( $data->get_param('type') ) ) {
            
        $ip = getIP();

        if ( !$ip )
        {
            return array('IsError'=>true, 'Message'=>'Địa chỉ IP không hợp lệ');
        }

        if ( !empty($data->get_param('ticketID')) )
        {
            $ticketID_check = validate_int( $data->get_param('ticketID') );
            if ( !$ticketID_check )
            {
                return array('IsError'=>true, 'Message'=>'TicketID không hợp lệ');
            }
            else
            {
                $ticketID = $data->get_param('ticketID');
            }
        }
        else
        {
            $ticketID = 0;
        }

        $data_form = array(
            'postID'    => $data->get_param('postID'),
            'ticketID'  => $ticketID,
            'page_name' => validate_text_input( $data->get_param('page_name') ),
            'page_url'  => validate_text_input( $data->get_param('page_url') ),
            'author'    => validate_text_input( $data->get_param('author') ),
            'phone'     => validate_text_input( $data->get_param('phone') ),
            'mail'      => $data->get_param('mail'),
            'content'   => trim(nl2br(strip_tags( $data->get_param('content') ))),
            'parent'    => $data->get_param('parent'),
            'ip'        => $ip,
            'type'      => trim($data->get_param('type')),
        );

        return $data_form;
    } else {
        return false;
    }
}

function validate_text_input( $data )
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function validate_email( $email )
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    else
    {
        return true;
    }
}

function validate_int( $int )
{
    if ( $int == '0')
    {
        return true;
    }
    elseif ( !filter_var($int, FILTER_VALIDATE_INT, array("options" => array("min_range"=> 0)) ) ) {
        return false;
    }
    else
    {
        return true;
    }
}

function validate_type( $type )
{
    if ( $type == 'post' || $type == 'product' || $type == 'page')
    {
        return true;
    }
    else
    {
        return false;
    }
}

?>