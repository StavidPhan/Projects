<?php
/*
*
* Sử dụng API này để nhận Cmt, reply từ CareSoft.
*
*/

add_action( 'rest_api_init', 'custom_listen_caresoft_api' );

function custom_listen_caresoft_api() {
    register_rest_route( 'comment-dtv-api/v1', 'listen-caresoft/reply', array (
                    'methods' => 'POST',
                    'callback' => 'replyCommentFromCareSoft',
                )
            );
    register_rest_route( 'comment-dtv-api/v1', 'listen-caresoft/status', array (
                'methods' => 'POST',
                'callback' => 'updateStatusTicketComment',
            )
        );
}

function replyCommentFromCareSoft() 
{
    $my_token = "t7MUbzWV03WvL-w";
    $ip = getIP();

    $headers = apache_request_headers();
    if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
        $token = (string)$matches[1];
    }
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);

    if ( $token == $my_token )
    {
        //$params = '{"agent_email":"onecenter24@gmail.com","ticket_id":8868,"content":"@117\n Helo anh em CPS t? CS"}';
        $_dataContent = explode("\n", $data['content']);
        $commentID = (int)trim(explode("\n", $data['content'])[0],'@');
        $content = '';

        if($commentID != 0)
        {
            $_comment = loadInfoComment( $commentID );
            if ( $_comment )
            {
                $_parentID = $_comment['comment_parent'];
            }
            else
            {
                // Write log
                writeCommentErrorLog('-------From CareSoft-----');
                writeCommentErrorLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
                writeCommentErrorLog('Result: Không tìm thấy comment ID');
                writeCommentErrorLog('-------------------------');
                return (object)array('IsError'=>true, 'Message'=>'Không tìm thấy comment ID');
            }

            foreach ($_dataContent as $key => $value)
            {
                if($key !== 0)
                {
                    $content .= trim($value).'<br/>';
                }
            }

            if ( $_parentID == 0 )
            {
                $_parentID = $commentID;
            }
            
            if ( empty($data['agent_name']) )
            {
                $data['agent_name'] = "Quản trị viên";
            }

            $_commentData = array(
                'postID'                    => $_comment['comment_post_ID'],                
                'author'		            => $data['agent_name'],
                'phone'	                    => '0',   
                'mail'	                    => $data['agent_email'],
                'content'			        => $content,
                'parent'					=> $_parentID,
                'ip'                        => $ip,
                'ticket_id'					=> $data['ticket_id'],
                'status'					=> '1',
                'is_admin'					=> 1,
                'type'                      => $_comment['comment_type'],
            );

            try 
            {
                $saveToDatabase = pushCommentToDatabase($_commentData);
                if ( $saveToDatabase->IsError == true )
                {
                    // Write log
                    writeCommentErrorLog('-------From CareSoft-----');
                    writeCommentErrorLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
                    writeCommentErrorLog('Result: Không thể lưu trả lời từ CareSoft');
                    writeCommentErrorLog('-------------------------');
                    $result = (object)array('IsError'=>true, 'Message'=>'Lỗi khi lưu dữ liệu. Check Log');
                }
                else
                {   
                    global $memcache;
                    // Delete Cache
                    $memcache->delete("countAllComment_Demo_".$_comment['comment_post_ID']);
                    $memcache->delete("loadChildComment_Demo_".$_comment['comment_post_ID']."_".$_parentID);
                    $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_0");
                    $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_1");

                    // Write log
                    writeCommentLog('-------From CareSoft-----');
                    writeCommentLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
                    writeCommentLog('Result: Nhận thành công');
                    writeCommentLog('-------------------------');
                    $result = (object)array('IsError'=>false, 'Message'=>'OK');
                }
            }
            catch (Exception $e) 
            {
                // Write log
                writeCommentErrorLog('-------From CareSoft-----');
                writeCommentErrorLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
                writeCommentErrorLog('Result: Không thể lưu trả lời từ CareSoft. Lỗi:'.json_encode($e->getMessage()) );
                writeCommentErrorLog('-------------------------');
                $result = (object)array('IsError'=>true, 'Message'=>$e->getMessage());
            }
        }
        else
        {
            // Write log
            writeCommentErrorLog('-------From CareSoft-----');
            writeCommentErrorLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
            writeCommentErrorLog('Result: Không tìm thấy comment ID' );
            writeCommentErrorLog('-------------------------');
            $result = (object)array('IsError'=>true, 'Message'=>'Không tìm thấy comment ID');
        }
    }
    else
    {
        // Write log
        writeCommentErrorLog('-------From CareSoft-----');
        writeCommentErrorLog('DTV nhận: Token: '.$token.' - Body: '.json_encode($data));
        writeCommentErrorLog('Result: Invalid Token!' );
        writeCommentErrorLog('-------------------------');
        $result = (object)array('IsError'=>true, 'Message'=>'Invalid Token!');
    }
    
    return $result;
}

function updateStatusTicketComment()
{
    $my_token = "t7MUbzWV03WvL-w";

    $headers = apache_request_headers();
    if ( !empty($headers['Authorization']) )
    {
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            $token = (string)$matches[1];
        }
    }
    else
    {
        // Write log
        writeCommentErrorLog('-------From CareSoft-----');
        writeCommentErrorLog('Update trạng thái: Token: '.$token);
        writeCommentErrorLog('Result: Invalid Token!' );
        writeCommentErrorLog('-------------------------');
        return (object)array('IsError'=>true, 'Message'=>'Invalid Token!');
    }
    
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);

    if ( $token == $my_token )
    {
        $commentID = (int)$data['comment_id'];
        $status_id = 1;
        $_newState = (int)$data['new_state'];
        
        switch ($_newState)
        {
            case 0:
                $status_id = 1;
                break;
            case 1:
                $status_id = 0;
                break;
            case 2:
                $status_id = 0;
                break;
            default:
                $status_id = 1;
                break;
        }

        if( $commentID !== 0 )
        {
            $_comment = loadInfoComment( $commentID );
            if ( $_comment )
            {
                try 
                {
                    $_updateStatus = updateStatus( $commentID, $status_id );

                    if ( !$_updateStatus )
                    {
                        // Write log
                        writeCommentErrorLog('-------From CareSoft-----');
                        writeCommentErrorLog('Update trạng thái: Token: '.$token.' - Body: '.json_encode($data));
                        writeCommentErrorLog('Result: Lỗi, kết nối DB' );
                        writeCommentErrorLog('-------------------------');
                        $result = (object)array('IsError'=>true, 'Message'=>'Lỗi, kết nối DB');
                    }
                    else
                    {
                        global $memcache;
                        
                        if( $_comment['comment_parent'] == 0)
                        {    
                            // Delete Cache
                            $memcache->delete("countAllComment_Demo_".$_comment['comment_post_ID']);
                            $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_0");
                            $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_1");
                            $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_2");
                        }
                        elseif( $_comment['comment_parent'] > 0 )
                        {
                            // Delete Cache
                            $memcache->delete("countAllComment_Demo_".$_comment['comment_post_ID']);
                            $memcache->delete("loadChildComment_Demo_".$_comment['comment_post_ID']."_".$_comment['comment_parent']);
                            $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_0");
                            $memcache->delete("loadParentComments_Demo_".$_comment['comment_post_ID']."_1");
                        }

                        $result = (object)array('IsError'=>false, 'Message'=>'OK - Update:'.$_updateStatus);
                    }               
                } 
                catch (Exception $e) 
                {
                    // Write log
                    writeCommentErrorLog('-------From CareSoft-----');
                    writeCommentErrorLog('Update trạng thái: Token: '.$token.' - Body: '.json_encode($data));
                    writeCommentErrorLog('Result: Không thể lưu trả lời từ CareSoft. Lỗi:'.json_encode($e->getMessage()) );
                    writeCommentErrorLog('-------------------------');
                    $result = (object)array('IsError'=>true, 'Message'=>$e->getMessage());
                }
            }
            else
            {
                // Write log
                writeCommentErrorLog('-------From CareSoft-----');
                writeCommentErrorLog('Update trạng thái: Token: '.$token.' - Body: '.json_encode($data));
                writeCommentErrorLog('Result: Không tìm thấy comment ID' );
                writeCommentErrorLog('-------------------------');
                return (object)array('IsError'=>true, 'Message'=>'Không tìm thấy comment ID');
            }
        }
        else
        {
            // Write log
            writeCommentErrorLog('-------From CareSoft-----');
            writeCommentErrorLog('Update trạng thái: Token: '.$token.' - Body: '.json_encode($data));
            writeCommentErrorLog('Result: Không tìm thấy comment ID' );
            writeCommentErrorLog('-------------------------');
            $result = (object)array('IsError'=>true, 'Message'=>'Không tìm thấy comment ID');
        }
    }
    else
    {
        // Write log
        writeCommentErrorLog('-------From CareSoft-----');
        writeCommentErrorLog('Update trạng thái: Token: '.$token.' - Body: '.json_encode($data));
        writeCommentErrorLog('Result: Invalid Token!' );
        writeCommentErrorLog('-------------------------');
        $result = (object)array('IsError'=>true, 'Message'=>'Invalid Token!');
    }
    
    return $result;
}
?>