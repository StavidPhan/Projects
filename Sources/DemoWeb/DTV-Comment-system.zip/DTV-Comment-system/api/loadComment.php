<?php
/*
*
* Sử dụng API này để loadComments trên website.
*
*/

add_action( 'rest_api_init', 'custom_load_comment_api' );

function custom_load_comment_api() {
    register_rest_route( 'comment-dtv-api/v1', 'load', array(
                    'methods' => 'POST',
                    'callback' => 'loadAction',
                )
            );
}

function loadAction($data)
{
    if ( $data->get_param('postID') && (int) $data->get_param('pageIndex') >= 0 )
    {
        if ( validate_int($data->get_param('postID')) && validate_int($data->get_param('pageIndex')) )
        {
            $postID = $data->get_param('postID');
            $pageIndex = $data->get_param('pageIndex');
        }
        else
        {
            return false;
        }
    }
    else
    {
        return 0;
    }
    
    global $wpdb;
    global $memcache;
    $cachekey = 'loadParentComments_Demo_'.$postID.'_'.$pageIndex;
    // Set Cache
    $listComments = $memcache->get($cachekey);

    if( !$listComments )
    {
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';
        $listComments = array();

        $query_getParent = $wpdb->prepare(" SELECT comment_ID, comment_post_ID, ticket_ID, comment_author, comment_content, comment_is_admin, comment_date
                                            FROM {$table_name}
                                            WHERE comment_post_ID = %d AND comment_status = %s AND comment_parent = 0
                                            ORDER BY comment_ID DESC
                                            LIMIT 10 OFFSET %d
                                        ", $postID, "1", 10*$pageIndex);
        $result_getParent = $wpdb->get_results($query_getParent, ARRAY_A );
        $listComments ['return'] = count($result_getParent);
        $listComments ['count'] = countAllComment($postID);

        foreach ($result_getParent as $item)
        {
            $child = loadChildComment( $postID, $item['comment_ID'] );
            $listComments ['comments'][] = array(
                'parent'    => $item,
                'child'     => $child,
            );
        }

        $memcache->set($cachekey, $listComments, false, 60*60*24*30); // 30 ngày
    }
    // return $listComments;
    return json_encode($listComments);
}

function loadChildComment( $postID, $parentID )
{
    global $wpdb;
    global $memcache;
    $cachekey = 'loadChildComment_Demo_'.$postID.'_'.$parentID;
    // Set Cache
    $result_getChild = $memcache->get($cachekey);

    if (!$result_getChild)
    {
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

        $query_getChild = $wpdb->prepare(" SELECT comment_ID, comment_post_ID, ticket_ID, comment_author, comment_content, comment_is_admin, comment_date
                                            FROM {$table_name}
                                            WHERE comment_post_ID = %d AND comment_status = %s AND comment_parent = %d
                                            ORDER BY comment_ID ASC
                                        ", $postID, "1", $parentID);
        $result_getChild = $wpdb->get_results($query_getChild, ARRAY_A );

        $memcache->set($cachekey, $result_getChild, false, 60*60*24*30); // 30 ngày
    }

    return $result_getChild;
}

function loadInfoComment( $commentID )
{
    global $wpdb;
    global $memcache;
    $cachekey = 'loadInfoComment_Demo_'.$commentID;

    // Set Cache
    $comment = $memcache->get($cachekey);

    if( !$comment )
    {
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

        $comment = $wpdb->get_row("SELECT * FROM $table_name WHERE comment_ID = $commentID", ARRAY_A);

        if (empty($comment))
        {
            return false;
        }
        else
        {
            $memcache->set($cachekey, $comment, false, 60*60*24*30); // 30 ngày
        }
    }

    return $comment;
}

function countAllComment( $postID )
{
    global $wpdb;
    global $memcache;
    $cachekey = 'countAllComment_Demo_'.$postID;
    // Set Cache
    $comment_count = $memcache->get($cachekey);

    if( !$comment_count )
    {
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

        $comment_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE comment_post_ID = $postID");

        $memcache->set($cachekey, $comment_count, false, 60*60*24*30); // 30 ngày
    }

    return $comment_count;
}

function getParentID( $commentID )
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

    $parentID = $wpdb->get_row("SELECT comment_parent FROM $table_name WHERE comment_ID = $commentID", ARRAY_A);

    if (empty($parentID))
    {
        return false;
    }
    else
    {
        return $parentID;
    }
}

function updateStatus( $commentID, $status )
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

    $query_update = "UPDATE $table_name SET comment_status = $status WHERE comment_ID = $commentID";
    $run = $wpdb->query( $query_update );

    if ( !$run )
    {
        return fasle;
    }
    else
    {
        return $run;
    }
}

?>