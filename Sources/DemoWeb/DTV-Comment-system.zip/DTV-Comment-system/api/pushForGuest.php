<?php
/*
*
* Sử dụng API này để nhận Cmt từ khách trên website.
*
*/

add_action( 'rest_api_init', 'custom_push_comment_api' );

function custom_push_comment_api() {
    register_rest_route( 'comment-dtv-api/v1', 'push', array(
                    'methods' => 'POST',
                    'callback' => 'pushAction',
                )
            );
}

function pushAction( $data ) 
{
    if ( isset($data) ) {
        $data_form = validata_data_form($data);
        if ( !$data_form || !empty($data_form['IsError']) )
        {
            return (object)array('IsError'=>true, 'Message'=>'Có lỗi! Vui lòng kiểm tra dữ liệu đầu vào');
        }
    } else {
        return (object)array('IsError'=>true, 'Message'=>'Có lỗi! Vui lòng kiểm tra dữ liệu đầu vào');
    }

    $result_saveToDatase = pushCommentToDatabase( $data_form );
    $commentID = $result_saveToDatase->data;
    
    if ($data_form['parent'] == 0)
    {
        $result_sentToCareSort = pushCommentToCareSoft( $commentID, $data_form );
    }
    else
    {
        $result_sentToCareSort = putCommentToCareSoft( $commentID, $data_form, $data_form['ticketID'] );
    }
    
    return json_encode($result_sentToCareSort);
}

function pushCommentToDatabase( $data_form ) 
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

    if ( empty($data_form['status']) )
    {
        $data_form['status'] = '1';
    }

    if ( empty($data_form['is_admin']) )
    {
        $data_form['is_admin'] = 0;
    }

    if ( empty($data_form['ticketID']) )
    {
        $data_form['ticketID'] = 0;
    }
    // $query_insert = $wpdb->prepare("INSERT INTO {$table_name} (comment_post_ID, comment_author, comment_author_phone, comment_author_email, comment_content, comment_parent, comment_author_IP, comment_type) 
    //                                 VALUES (%d, %s, %s, %s, %s, %d, %s, %s)", 
    //                                 $data_form['postID'], $data_form['author'], $data_form['phone'], $data_form['mail'], $data_form['content'], $data_form['parent'], $data_form['ip'], $data_form['type']
    //                             );
    // $result_insert = $wpdb->query($query_insert);

    $table_data = array(
        "comment_post_ID"           => $data_form['postID'],
        "ticket_ID"                 => (int)$data_form['ticketID'],
        "comment_author"            => $data_form['author'],
        "comment_author_phone"      => $data_form['phone'],
        "comment_author_email"      => $data_form['mail'],
        "comment_content"           => $data_form['content'],
        "comment_parent"            => $data_form['parent'],
        "comment_author_IP"         => $data_form['ip'],
        "comment_type"              => $data_form['type'],
        "comment_status"            => $data_form['status'],
        "comment_is_admin"          => $data_form['is_admin'],
    );
    $table_format = array(
        '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d'
    );

    $result_insert = $wpdb->insert( $table_name, $table_data, $table_format);
    $commentID = $wpdb->insert_id;
    
    if ( !$result_insert )
    {
        // Write Error log
        writeCommentErrorLog('-------Database-----');
        writeCommentErrorLog('Send post params: '.json_encode($data_form));
        writeCommentErrorLog('Result: Không thể lưu comment vào DB');
        writeCommentErrorLog('--------------------');
        return (object)array('IsError'=>true, 'Message'=>'Không thể lưu comment vào DB');
    } 
    else 
    {
        // Write log
        writeCommentLog('-------Database-----');
        writeCommentLog('Send post params: '.json_encode($data_form));
        writeCommentLog('--------------------');
        return (object)array('IsError'=>false, 'Message'=>'Lưu thành công', 'data'=>$commentID);
    }
}

function pushCommentToCareSoft( $commentID, $data_form)
{
    // API CareSoft
    $api_caresoft = "https://test.caresoft.vn/vi2/api/v1/tickets";
    $token = "FeB2nTAy";
    $authorization = "Authorization: Bearer ".$token;
    $service_id = "9500001";
    
    // Xử lý Data trước khi gửi đi

    $content = '#'.$commentID.PHP_EOL;
    $content .= ' '.$data_form['content'].'<br/>';
    $content .= ' '.$data_form['page_url'];
    // $content .= ' https://demo.dienthoaivui.com.vn';
    
    $postData = array();
    $postData['ticket'] = array(
        'ticket_subject' 	=> $data_form['page_name'].' #'.$commentID,
        'username' 			=> $data_form['author'],
        'ticket_comment'	=> $content,
        'email'				=> $data_form['mail'],
        'phone'				=> $data_form['phone'],
        'ticket_priority' 	=> 'urgent',
        'service_id'		=> $service_id,
    );
    $data_string = json_encode($postData);

    // Code Sent
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $api_caresoft,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data_string,
        CURLOPT_HTTPHEADER => array(
            $authorization,
            "Cache-Control: no-cache",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
            'Content-Type: application/json',
            "cache-control: no-cache",
            ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    $response = json_decode($response);

    if ($err) {
        // Write Error log
        writeCommentErrorLog('-------CareSoft-----');
        writeCommentErrorLog('Send post params: '.json_encode($data_form));
        writeCommentErrorLog('Result: Không thể gửi comment sang CareSoft - '.$err);
        writeCommentErrorLog('--------------------');
        return (object)array('IsError'=>true, 'Message'=>'Không thể gửi comment sang CareSoft - '.$err);
    } elseif( $response->code == "errors" ) {
        // Write Error log
        writeCommentErrorLog('-------CareSoft-----');
        writeCommentErrorLog('Send post params: '.json_encode($data_form));
        writeCommentErrorLog('Result: Có lỗi trong quá trình gửi CareSoft - '.$response->message);
        writeCommentErrorLog('--------------------');
        return (object)array('IsError'=>true, 'Message'=>'Có lỗi trong quá trình gửi CareSoft - '.$response->message);
    } else {
        $ticketID = $response->ticket->ticket_id;
        global $wpdb;
        global $memcache;
        $table_name = $wpdb->prefix . 'CommentSystem_WithCareSoft';

        $data_update = array(
            "ticket_ID"  => $ticketID,
        );
        $where = array(
            "comment_ID" => $commentID,
        );

        $updated = $wpdb->update( $table_name, $data_update, $where );

        if (!$updated)
        {
            // Write Error log
            writeCommentErrorLog('-------Database-----');
            writeCommentErrorLog('Result: Có lỗi trong quá trình update TicketID cho comment: '.$commentID.' - TicketID: '.$ticketID);
            writeCommentErrorLog('--------------------');
            return (object)array('IsError'=>true, 'Message'=>'Có lỗi trong quá trình update TicketID cho comment: '.$commentID.' - TicketID: '.$ticketID, 'data'=>json_encode($response) );
        } 
        
        // Delete Cache
        $memcache->delete("countAllComment_Demo_".$data_form['postID']);
        $memcache->delete("loadParentComments_Demo_".$data_form['postID']."_0");
        $memcache->delete("loadParentComments_Demo_".$data_form['postID']."_1");
        $memcache->delete("loadParentComments_Demo_".$data_form['postID']."_2");

        // Write log
        writeCommentLog('-------CareSoft-----');
        writeCommentLog('Send post params: '.$data_string);
        writeCommentLog('Result: Gửi thành công - '.json_encode($response));
        writeCommentLog('--------------------');
        return (object)array('IsError'=>false, 'Message'=>'Gửi thành công', 'data'=>json_encode($response) );
    }
}

function putCommentToCareSoft( $commentID, $data_form, $ticketID )
{
    // Memcache
    global $memcache;

    // API CareSoft
    $api_caresoft = "https://test.caresoft.vn/vi2/api/v1/tickets/".$ticketID;
    $token = "FeB2nTAy";
    $authorization = "Authorization: Bearer ".$token;
    $service_id = "9500001";
    
    // Xử lý Data trước khi gửi đi

    $content = '#'.$commentID.PHP_EOL;
    $content .= ' '.$data_form['content'].'<br/>';
    $content .= ' '.$data_form['page_url'];
    // $content .= ' https://demo.dienthoaivui.com.vn';
    
    $_replyData = array();
    $_replyData['ticket'] = array(
        'ticket_subject' 	=> $data_form['page_name'].' #'.$commentID,
        'username' 			=> $data_form['author'],
        'ticket_comment'	=> array (
            'body' 		=> $content,
            'is_public' => 1
        ),
        'email'				=> $data_form['mail'],
        'ticket_status'		=> 'open',
        'phone'				=> $data_form['phone'],
        'ticket_priority' 	=> 'urgent',
        'service_id'		=> $service_id
    );
    $data_string = json_encode($_replyData);

    // Code Sent
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $api_caresoft,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => $data_string,
        CURLOPT_HTTPHEADER => array(
            $authorization,
            "Cache-Control: no-cache",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
            'Content-Type: application/json',
            "cache-control: no-cache",
            ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    $response = json_decode($response);

    if ($err) {
        // Write Error log
        writeCommentErrorLog('-------CareSoft-----');
        writeCommentErrorLog('Send post params: '.json_encode($data_form));
        writeCommentErrorLog('Result: Không thể update comment sang CareSoft - '.$err);
        writeCommentErrorLog('--------------------');
        return (object)array('IsError'=>true, 'Message'=>'Không thể update comment sang CareSoft - '.$err);
    } elseif( $response->code == "errors" || $response == NULL ) {
        // Write Error log
        writeCommentErrorLog('-------CareSoft-----');
        writeCommentErrorLog('Send post params: '.json_encode($data_form));
        writeCommentErrorLog('Result: Có lỗi trong quá trình gửi CareSoft - '.json_encode($response->message));
        writeCommentErrorLog('--------------------');
        return (object)array('IsError'=>true, 'Message'=>'Có lỗi trong quá trình update comment CareSoft - '.$response->message); // Nếu không có $response->message tức là NULL
    } else {

        // Delete Cache
        $memcache->delete("countAllComment_Demo_".$data_form['postID']);
        $memcache->delete("loadChildComment_Demo_".$data_form['postID']."_".$data_form['parent']);
        $memcache->delete("loadParentComments_Demo_".$data_form['postID']."_0");
        $memcache->delete("loadParentComments_Demo_".$data_form['postID']."_1");

        // Write log
        writeCommentLog('-------CareSoft-----');
        writeCommentLog('Send post params: '.$data_string);
        writeCommentLog('Result: Gửi thành công - '.json_encode($response));
        writeCommentLog('--------------------');
        return (object)array('IsError'=>false, 'Message'=>'Update thành công', 'parentID'=> $data_form['parent'], 'data'=>json_encode($response) );
    }
}

?>