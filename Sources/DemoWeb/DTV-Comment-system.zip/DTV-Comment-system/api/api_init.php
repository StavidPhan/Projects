<?php
/**
 * Plugin Name: DTV Comment System
 * Plugin URI: https://ducdoblog.com
 * Description: Hệ thống Comment Điện Thoại Vui liên kết với CareSoft
 * Version: 1.0.0
 * Author: iRisVN
 * Author URI: https://ducdoblog.com
 * License: GPLv2 or later 
 * Description File: Chứa bên trong phần API của Plugin
 */

// List File
require_once( DTV_COMMENTS_DIR . 'api/pushForGuest.php');
require_once( DTV_COMMENTS_DIR . 'api/listenFromCareSoft.php');
require_once( DTV_COMMENTS_DIR . 'api/loadComment.php');
?>