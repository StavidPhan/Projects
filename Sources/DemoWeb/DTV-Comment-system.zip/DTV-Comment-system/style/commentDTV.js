var postID = jQuery("#postID_field").val();
var postType_field = jQuery("#postType_field").val();
var page_name = jQuery("#page_name_field").val();
var page_url = jQuery("#page_url_field").val();

var commentDTV = {
    backToMainCmt: function(){
        jQuery('.form_reply_wrap').html('');
        jQuery('#comment-error').remove();
		jQuery('.main_comment .user_action').show();
	},
    sendCmt: function() {
		jQuery("#comment-error").remove();
		var currentContent = jQuery('textarea#writeComment').val().trim();
		
		//Stop XSS
		currentContent = currentContent.replace(/<br>/gi, "\n");
		currentContent = currentContent.replace(/<p.*>/gi, "\n");
		currentContent = currentContent.replace(/<a.*href="(.*?)".*>(.*?)<\/a>/gi, " $2 (Link->$1) ");
		currentContent = currentContent.replace(/<[^>]+>/g, '');
        
		if(!currentContent){
			jQuery(".main_comment").after('<span id="comment-error" class="error">Vui lòng nhập bình luận</span>');
			return false;
		}else if(currentContent.length < 10){
			jQuery(".main_comment").after('<span id="comment-error" class="error">Bình luận của bạn quá ngắn.</span>');
			return false;
		}else{
			jQuery("#comment-error").remove();
		}
		
		// jQuery('#lastParentId').val('');
		jQuery('#lastCmtContent').val(currentContent);
		jQuery(".main_comment #FullInfo").modal('show');
    },
    replyCmtAction: function(parentId,ticketId){
        jQuery('textarea#writeComment').val('');
        
		var html = '';
		html = html + '<div class="form_reply_input">';
            html = html + '<form id="form_reply_'+ parentId + '" class="form_reply">';
                html = html + '<textarea id="form_reply_field_'+parentId+'" placeholder="Xin mời để lại câu hỏi, Điện Thoại Vui sẽ trả lời trong 30 phút từ 8h - 22h mỗi ngày ."></textarea>';
                html = html + '<div class="user_action">';
                    html = html + '<div class="rule"><a href="javascript:void(0)">Hướng dẫn hỏi đáp</a></div>';
                    html = html + '<div class="sentComment"><a class="button" href="javascript:void(0)" id="button_sendComment" onclick="commentDTV.sendCmtReply('+parentId+','+ticketId+');">Gửi</a></div>';
                html = html + '</div>';
            html = html + '</form>';
        html = html + '</div>';
        
        jQuery('.form_reply_wrap').html('');
        jQuery('#comment-error').remove();
		jQuery('.main_comment .user_action').hide();
		jQuery('#form_reply_'+parentId).html(html);
		jQuery('#lastCmtContent').val(jQuery('textarea#form_reply_field_'+parentId).val());
		jQuery('#lastParentId').val(parseInt(parentId));
		jQuery('#lastTicketId').val(parseInt(ticketId));
	},
	// Reply comment send
	sendCmtReply: function (parentId,ticketId){
		jQuery("#comment-error").remove();
		var currentContent = jQuery('textarea#form_reply_field_'+parentId).val().trim();
		if(!currentContent){
			jQuery('#form_reply_'+parentId).after('<span id="comment-error" class="error">Vui lòng nhập bình luận</span>');
			return false;
		}else if(currentContent.length < 10){
			jQuery('#form_reply_'+parentId).after('<span id="comment-error" class="error">Bình luận của bạn quá ngắn. Vui lòng nhập lại</span>');
			return false;
		}else{
			jQuery("#comment-error").remove();
		}
		
		jQuery('#lastCmtContent').val(currentContent);
		jQuery('#lastParentId').val(parentId);
		jQuery('#lastTicketId').val(ticketId);
		jQuery(".main_comment #FullInfo").modal('show');
	},
    loadComment: function( $pageIndex ) {
		jQuery.ajax({
			type: "POST",
			url: "/wp-json/comment-dtv-api/v1/load",
			data: {
				"postID": postID, // postID
				"pageIndex": $pageIndex,
			},
			success: function (result) {
                if (result)
                {
                    var html = '';
                    var data = JSON.parse(result);
                    // console.log(data);
					
					if (data.count && parseInt(data.count) > 0)
					{
						jQuery("div#header_comment h3").html("<h3>Hỏi và đáp ("+data.count+" bình luận)</h3>");
					}
                    html = service._commentToHtml(data, $pageIndex);

                    jQuery('#product_comment_list_'+postID).html(html);
                }
			}
		});
    },
    loadMore: function( $pageIndex ) {
        
        $pageIndex = $pageIndex + 1;

        jQuery.ajax({
			type: "POST",
			url: "/wp-json/comment-dtv-api/v1/load",
			data: {
				"postID": postID, // postID
				"pageIndex": $pageIndex,
			},
			success: function (result) {
                if (result)
                {
                    var html = '';
                    var data = JSON.parse(result);
                    // console.log(data);

                    html = service._commentToHtml(data, $pageIndex);

                    jQuery("#cmt_loadmore").remove();
                    jQuery('#product_comment_list_'+postID).append(html);
                }
			}
		});
    }
};

var push_comment  = jQuery("button[id='push_comment']");
push_comment.click(function(){
    var data = jQuery('form#comment-form').serialize();
	var action = '/wp-json/comment-dtv-api/v1/push';
	var hoten = jQuery('#nickname_field').val().trim();
    var sodienthoai = jQuery('#phone_field').val();
    var mail = jQuery('#mail_field').val();
	var contentComment = jQuery('#lastCmtContent').val().trim();
    var phoneFormat = /((09|03|07|08|05)+([0-9]{8})\b)/s;
	var hotenFormat = /^[^!@#$%^&*()_+=\-\[\]\:\'\"\;\.\?\<\>\|\\0-9]+$/s;
	var mailFormat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z-]+)*$/s;

    var isOk = true;
	var html = '';

	//Stop XSS
	contentComment = contentComment.replace(/<br>/gi, "\n");
	contentComment = contentComment.replace(/<p.*>/gi, "\n");
	contentComment = contentComment.replace(/<a.*href="(.*?)".*>(.*?)<\/a>/gi, " $2 (Link->$1) ");
	contentComment = contentComment.replace(/<[^>]+>/g, '');

	jQuery('#nickname-error').remove();
	jQuery('#phone-error').remove();
	jQuery('#mail-error').remove();

	if(hoten == ''){
		jQuery('#nickname_field').addClass('error-note');
		jQuery('#nickname_field').after( '<label id="nickname-error" class="error" for="nickname">Quý khách cần điền họ tên</label>');
		isOk = false;
    }else if(hotenFormat.test(hoten) == false || hoten.length > 40){
        jQuery('#nickname_field').addClass('error-note');
		jQuery('#nickname_field').after( '<label id="nickname-error" class="error" for="nickname">Họ tên không được chứa số và ký tự đặc biệt</label>');
		isOk = false;
    }else{
		jQuery('#nickname_field').removeClass('error-note');
		jQuery('#nickname-error').remove();
    }
    
    if(mail == ''){
        jQuery('#mail_field').addClass('error-note');
		jQuery('#mail_field').after( '<label id="mail-error" class="error" for="nickname">Quý khách cần điền địa chỉ Mail</label>');
		isOk = false;
	}else if(mailFormat.test(mail) == false || mail.length > 50){
		jQuery('#mail_field').addClass('error-note');
		jQuery('#mail_field').after( '<label id="mail-error" class="error" for="nickname">Địa chỉ mail không đúng định dạng</label>');
		isOk = false;
	}else{
		jQuery('#mail_field').removeClass('error-note');
		jQuery('#mail-error').remove();
    }

	if(sodienthoai == ''){
		jQuery('#phone_field').addClass('error-note');
		jQuery('#phone_field').after('<label id="phone-error" class="error" for="phone">Quý khách cần nhập số điện thoại</label>');
		isOk = false;
	} else if (phoneFormat.test(sodienthoai) == false){
		jQuery('#phone_field').addClass('error-note');
		jQuery('#phone_field').after('<label id="phone-error" class="error" for="phone">Số điện thoại không đúng định dạng</label>');
		isOk = false;
	} else if (sodienthoai.length < 10 || sodienthoai.length > 20){
		jQuery('#phone_field').addClass('error-note');
		jQuery('#phone_field').after('<label id="phone-error" class="error" for="phone">Số điện thoại ít nhất là 10 số</label>');
		isOk = false;
	}else{
		jQuery('#phone_field').removeClass('error-note');
		jQuery('#phone-error').remove();
	}

	if(isOk == true){
		jQuery.ajax({
			type: "POST",
			url: action,
			data: data,
			beforeSend: function () {
				jQuery('#simple_loader').show();
			},
			success: function (result) {
				var data = JSON.parse(result);
				if(!data.IsError){

                    var xuLyResult = data.data;
                    xuLyResult = JSON.parse(xuLyResult);
                    var ticket_subject = xuLyResult.ticket.ticket_subject.split("#");
                    var ticket_ID = xuLyResult.ticket.ticket_id;
                    var comment_ID = ticket_subject[1];

                    jQuery('#simple_loader').hide();
                    // console.log(data);
					jQuery('form#comment-form').trigger("reset");
					jQuery('form.form_reply').trigger("reset");
                    jQuery('textarea#writeComment').val('');
                    
                    // Add new comment

                    if (data.parentID)
                    {
						var parent_ID = data.parentID;
						html = html + '<div class="reply_list">';
							html = html + '<div class="cmt_item rep_item" id="item_'+comment_ID+'" style="border-top: 1px solid #dfdfdf;padding: 10px 5px 5px 5px;">';
								html = html + '<div class="rowuser"><a href="javascript:void(0)"><div>'+hoten.charAt(0)+'</div><strong>'+hoten+'</strong></a></div>';
								html = html + '<div class="question">'+contentComment+'</div>';
								html = html + '<div class="actionuser"><a href="javascript:void(0)" class="respondent" onclick="commentDTV.replyCmtAction('+parent_ID+','+ticket_ID+')"> <i class="fa fa-commenting" aria-hidden="true"></i> Trả lời</a>';
								html = html + '<a href="javascript:void(0)" class="time">| 1 giây trước </a></div>';
							html = html + '</div>';
						html = html + '</div>';
						html = html + '<div class="form_reply_wrap" id="form_reply_'+parent_ID+'"></div>';
						jQuery("#form_reply_"+parent_ID).remove();
                        jQuery("#item_"+ parent_ID).append(html);
                    }
                    else
                    {
                        var parent_ID = comment_ID;
                        html = html + '<li class="cmt_item" id="item_'+comment_ID+'">';
                            html = html + '<div class="rowuser"><a href="javascript:void(0)"><div>'+hoten.charAt(0)+'</div><strong>'+hoten+'</strong></a></div>';
                            html = html + '<div class="question">'+contentComment+'</div>';
                            html = html + '<div class="actionuser"><a href="javascript:void(0)" class="respondent" onclick="commentDTV.replyCmtAction('+parent_ID+','+ticket_ID+')"> <i class="fa fa-commenting" aria-hidden="true"></i> Trả lời</a>';
                            html = html + '<a href="javascript:void(0)" class="time">| 1 giây trước </a></div>';
							html = html + '<div class="reply_list" style="display:none;"></div>';
							html = html + '<div class="form_reply_wrap" id="form_reply_'+comment_ID+'"></div>';
                        html = html + '</li>';
                        jQuery(".showListComment .listComment").prepend(html);
                    }

                    // Add new comment

					commentDTV.backToMainCmt();
					jQuery(".main_comment #FullInfo").modal('hide');
				}else{
					alert(data.Message);
					return false;
				}
			}
		});
	}
	return false;
});		

var service = {
	phone_num_regex: /(0|\+)([0-9]{3})([0-9]{6,9})([^0-9^-]|\<|$)/m,
	// Detect URL
	urlify: function(text){
		var urlRegex = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
	    return text.replace(urlRegex, function (url) {
	        return '<a href="' + url + '" target="_blank">' + url + '</a>';
	    })
	},
	// Hide phone no
	hidePhoneNo: function(str, regex){
	    var retstr = str;
	    var rx = service.phone_num_regex;
	    if (regex) {
	        rx = regex;
	    }
	    retstr = str.replace(rx, "$1$2******$4");

	    return retstr;
	},
	getTimeComment(date) {
		var strToTime = new Date(date.replace(/\s+/g, 'T').concat('.000+07:00'));
		var seconds = Math.floor((new Date() - strToTime) / 1000);
		var interval = Math.floor(seconds / 31536000);
	
		if (interval >= 1) {
		  return interval + " năm trước";
		}
		interval = Math.floor(seconds / 2592000);
		if (interval >= 1) {
		  return interval + " tháng trước";
		}
		interval = Math.floor(seconds / 86400);
		if (interval >= 1) {
		  return interval + " ngày trước";
		}
		interval = Math.floor(seconds / 3600);
		if (interval >= 1) {
		  return interval + " giờ trước";
		}
		interval = Math.floor(seconds / 60);
		if (interval >= 1) {
		  return interval + " phút trước";
		}
		return Math.floor(seconds) + " giây trước";
	},
	_commentToHtml: function (data, $pageIndex){
		var html = '';
		jQuery.each(data.comments, function(key, comment){
            var parent_content = service.hidePhoneNo(comment.parent.comment_content);
            
			html = html + '<li class="cmt_item" id = "item_'+comment.parent.comment_ID+'">';
			
			if(comment.parent.comment_is_admin == "1"){
				html = html + '<div class="rowuser"><a href="javascript:void(0)"><div class="cmt_admin"></div><strong>'+comment.parent.comment_author+'</strong></a>';
				html = html + '<b class="qtv">QTV</b>';
				parent_content = service.urlify(comment.parent.comment_content);
			}else{
				if(comment.parent.comment_author){
					html = html + '<div class="rowuser"><a href="javascript:void(0)"><div>'+comment.parent.comment_author.charAt(0)+'</div><strong>'+comment.parent.comment_author+'</strong></a>';
				}else{
					html = html + '<div class="rowuser"><a href="javascript:void(0)"><div>'+'G'+'</div><strong>Guest</strong></a>';
				}
			}
			
			html = html + '</div>';
			html = html + '<div class="question">'+parent_content+'</div>';
			html = html + '<div class="actionuser"><a href="javascript:void(0)" class="respondent" onclick="commentDTV.replyCmtAction('+comment.parent.comment_ID+','+comment.parent.ticket_ID+')"> <i class="fa fa-commenting" aria-hidden="true"></i> Trả lời</a>';
			html = html + '<a href="javascript:void(0)" class="time">| '+service.getTimeComment(comment.parent.comment_date)+'</a></div>';
			if(comment.child.length > 0){
				html = html + '<div class="reply_list">';
				html = html + '<span><font class="fa fa-caret-up fa-2x"></font></span>';
				jQuery.each(comment.child, function(key, reply){
					var reply_content = service.hidePhoneNo(reply.comment_content);;
					if(key == 0){
						html = html + '<div class="cmt_item rep_item" id="item_'+reply.comment_ID+'">';
					}else{
						html = html + '<div class="cmt_item rep_item" id="item_'+reply.comment_ID+'" style="border-top: 1px solid #dfdfdf;padding: 10px 5px 5px 5px;">';
					}

					if(reply.comment_is_admin == "1"){
						html = html + '<div class="rowuser"><a href="javascript:void(0)"><div class="cmt_admin"></div><strong>'+reply.comment_author+'</strong></a>';
						html = html + '<b class="qtv">QTV</b>';
						reply_content = service.urlify(reply.comment_content);
					}else{
						html = html + '<div class="rowuser"><a href="javascript:void(0)"><div>'+reply.comment_author.charAt(0)+'</div><strong>'+reply.comment_author+'</strong></a>';
					}
					html = html + '</div>';
					html = html + '<div class="question">'+reply_content+'</div>';
					html = html + '<div class="actionuser"><a href="javascript:void(0)" class="respondent" onclick="commentDTV.replyCmtAction('+comment.parent.comment_ID+','+comment.parent.ticket_ID+')"> <i class="fa fa-commenting" aria-hidden="true"></i> Trả lời</a>';
					html = html + '<a href="javascript:void(0)" class="time">| '+service.getTimeComment(reply.comment_date)+'</a></div>';
					html = html + '</div>';
				});
				html = html + '</div>';
				html = html + '</div>';
			}
			html = html + '<div class="form_reply_wrap" id="form_reply_'+comment.parent.comment_ID+'"></div>';
			html = html + '</li>';
        });
        if (data.return >= 10)
        {
            html = html + '<div class="row" style="text-align: center;">';
                html = html + '<a id="cmt_loadmore" href="javascript:void(0)" class="btn btn-default btn-sm" onclick="commentDTV.loadMore('+ $pageIndex +')" rel="nofollow">Xem thêm</a>';
            html = html + '</div>';
        }
		return html;
	}
};

commentDTV.loadComment(0);