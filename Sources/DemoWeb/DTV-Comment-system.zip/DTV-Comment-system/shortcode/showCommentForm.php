<?php
/*
*
* Sử dụng ShortCode này để Show Comment Form trên website.
*
*/

function showCommentForm()
{
    if ( is_product() )
    {
        global $product;
        $postID = $product->get_id();
        $page_name = $product->get_title();
        $page_url = get_permalink( $postID );
        $postType = "product";
    }
    elseif ( is_singular("page") )
    {
        global $post;
        $postID = $post->ID;
        $page_name = $post->post_title;
        $page_url = get_permalink( $postID );
        $postType = "page";
    }
    else
    {
        global $post;
        $postID = $post->ID;
        $page_name = $post->post_title;
        $page_url = get_permalink( $postID );
        $postType = "post";
    }
?>
    <section class="CommentDTV" >
        <div id="header_comment">
            <h3>Hỏi và đáp</h3>
        </div>
        <div class="row main_comment">
            <textarea id="writeComment" placeholder="Xin mời để lại câu hỏi, Điện Thoại Vui sẽ trả lời trong 1h từ 8h - 22h mỗi ngày." onfocus="commentDTV.backToMainCmt()"></textarea>
            <div class="user_action">
                <div class="rule">
                    <a href="javascript:void(0)">Hướng dẫn hỏi đáp</a>
                </div>
                <div class="sentComment">
                    <a class="button" href="javascript:void(0)" id="button_sendComment" onclick="commentDTV.sendCmt();">Gửi</a>
                </div>
            </div>
            <div id="FullInfo" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Thông tin người gửi</h4>
                        </div>
                        <div class="modal-body">
                            <form method="POST" id="comment-form" class="popup_cmt_form">
                                <input type="text" name="author" id="nickname_field" class="input-text required-entry" value="" placeholder="Họ tên (bắt buộc)">  
                                <input type="text" name="phone" id="phone_field" class="input-text required-entry" value="" placeholder="Số điện thoại (bắt buộc)">  
                                <input type="text" name="mail" id="mail_field" class="input-text required-entry" value="" placeholder="Địa chỉ mail để nhận phản hồi">  
                                <!-- Send Hidden -->
                                <input type="hidden" name="content" id="lastCmtContent" value="">
                                <input type="hidden" name="postID" id="postID_field" value="<?php echo $postID ?>">
                                <input type="hidden" name="type" id="postType_field" value="<?php echo $postType ?>">
                                <input type="hidden" name="page_name" id="page_name_field" value="<?php echo $page_name ?>">
                                <input type="hidden" name="page_url" id="page_url_field" value="<?php echo $page_url ?>">
                                <input type="hidden" name="parent" id="lastParentId" value="0">
                                <input type="hidden" name="ticketID" id="lastTicketId" value="0">
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button id="push_comment" type="button" class="btn btn-block btn-default">Gửi bình luận</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- List Comment -->
        <div class="showListComment">
            <ul class="listComment" id="product_comment_list_<?php echo $postID ?>">
            </ul>
        </div>
        <div id="simple_loader"></div>
    </section>

    <link async rel='stylesheet' href='/wp-content/plugins/dtv-comments-system/style/commentDTV.min.css?ver=1.3.0' type='text/css' media='all' />
    <script defer type='text/javascript' src='/wp-content/plugins/dtv-comments-system/style/commentDTV.min.js?ver=1.5.0'></script>
<?php
}

add_shortcode( 'commentDTV', 'showCommentForm' );

?>