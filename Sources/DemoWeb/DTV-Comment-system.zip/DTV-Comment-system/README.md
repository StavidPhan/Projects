# DTV-Comment-system

Đây là lần đầu tiên tự mình làm 1 Plugin bự đến vậy.
Lúc đầu nghĩ mãi, nghĩ mãi ... hay là custom lại phần Comment của Wordpress. Haizz
Nhưng mà nó vướng quá nhiều thứ trong đó ... nào là Core, phải hack code, tìm hook, filter, ... 
Tóm lại tự mình hạ quyết tâm build 1 plugin Comment riêng. 

- Thời gian build: Tròn 1 tuần.
- Cảm ơn đại ca Tún đã hỗ trợ thằng đệ làm Plugin này <3 

- Link Demo: https://demo.dienthoaivui.com.vn/sua-main-sua-rung-oppo-f3/
or https://demo.dienthoaivui.com.vn/test-com/