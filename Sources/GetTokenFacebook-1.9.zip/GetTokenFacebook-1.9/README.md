# GetTokenFacebook
Tool dùng để lấy token facebook từ email và password.   
Cách lấy token được giới thiệu tại đây: https://www.siblog.net/2019/02/api-get-token-facebook-full-quyen-khong-checkpoint.html   
Tool tương tự của Vy Nghĩa: https://www.facebook.com/pagevynghia/posts/2452869638282083   

Hình ảnh của tool:
![alt text](https://i.imgur.com/AvU0yql.jpg)
