﻿namespace FBToken.Main.Core
{
    public interface ISettingsRepos
    {
        string LastLoggedInEmail { get; set; }
    }
}