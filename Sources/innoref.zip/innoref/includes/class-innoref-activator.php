<?php

/**
 * Fired during plugin activation
 *
 * @link       https://catsplugins.com/
 * @since      1.0.0
 *
 * @package    Innoref
 * @subpackage Innoref/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Innoref
 * @subpackage Innoref/includes
 * @author     Cat's Plugins <support@catsplugins.com>
 */
class Innoref_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
